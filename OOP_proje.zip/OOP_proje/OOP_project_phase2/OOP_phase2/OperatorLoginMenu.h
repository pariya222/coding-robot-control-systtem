#ifndef OPERATOR_LOGIN_MENU_H
#define OPERATOR_LOGIN_MENU_H

#include <vector>
#include <string>
#include "RobotOperator.h"

class OperatorLoginMenu {
private:
    std::vector<RobotOperator> operators;
    RobotOperator* loggedInOperator;

public:
    OperatorLoginMenu(const std::vector<RobotOperator>& operatorList);  // Kurucu fonksiyon ekleniyor
    RobotOperator* findOperatorByName(const std::string& name);
    RobotOperator* findOperatorBySurname(const std::string& surname);
    void showLoginMenu();
    void logout();
    bool isLoggedIn() const;
    void displayLoggedInOperatorDetails() const;
    RobotOperator* getLoggedInOperator() const;
};

#endif // OPERATOR_LOGIN_MENU_H
