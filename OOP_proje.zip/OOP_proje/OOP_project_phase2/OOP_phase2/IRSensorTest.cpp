#include "IRSensor.h"
#include "FestoRobotAPI.h"
#include <iostream>
using namespace std;

/**
 * @file IRSensorTest.cpp
 * @brief Main program to demonstrate interaction with IRSensor using FestoRobotAPI.
 *
 * @date December 2024
 * @author Mervenur �akmako�lu (152120221128@ogrenci.ogu.edu.tr)
 */

 /** Global pointer to the robot API */
FestoRobotAPI* robotino;

/**
 * @brief Prints the IR sensor readings.
 *
 * This function retrieves the robot's pose (position and orientation) and updates the IR sensor readings.
 * It then prints the sensor readings using both the operator[] and getRange method.
 */
void printSensorValues(FestoRobotSensorInterface* sensor) {
    /** Print sensor type */
    cout << "Sensor Type: " << sensor->getSensorType() << endl;

    /** Print all sensor readings */
    for (int i = 0; i < 9; i++) {
        cout << "Sensor[" << i << "] = " << sensor->getSensorValue(i) << endl;
    }
    cout << "----------------------------------------------------------------------" << endl;
}

/**
 * @brief Main function to control robot movement and print sensor values.
 *
 * This function connects to the robot, performs several movements (forward, backward, left, right, and rotation),
 * and prints the corresponding sensor values after each movement.
 *
 * @return int Exit status code.
 */
int main() {
    /** Create connection to robot */
    robotino = new FestoRobotAPI();

    cout << "Connecting to robot..." << endl;

    /** Make connection to robot */
    robotino->connect();
    Sleep(2000);  /**< Wait for the robot to connect */

    /** Create IRSensor object */
    IRSensor irSensor(robotino);

    /** Update and print sensor values */
    irSensor.update();
    printSensorValues(&irSensor);

    /** Move forward and print sensor values */
    cout << "Moving forward..." << endl;
    robotino->move(FORWARD);
    Sleep(2000);
    robotino->stop();
    irSensor.update();
    printSensorValues(&irSensor);

    /** Move backward and print sensor values */
    cout << "Moving backward..." << endl;
    robotino->move(BACKWARD);
    Sleep(2000);
    robotino->stop();
    irSensor.update();
    printSensorValues(&irSensor);

    /** Move left and print sensor values */
    cout << "Moving left..." << endl;
    robotino->move(LEFT);
    Sleep(2000);
    robotino->stop();
    irSensor.update();
    printSensorValues(&irSensor);

    /** Move right and print sensor values */
    cout << "Moving right..." << endl;
    robotino->move(RIGHT);
    Sleep(2000);
    robotino->stop();
    irSensor.update();
    printSensorValues(&irSensor);

    /** Rotate left and print sensor values */
    cout << "Rotating left..." << endl;
    robotino->rotate(LEFT);
    Sleep(2000);
    robotino->stop();
    irSensor.update();
    printSensorValues(&irSensor);

    /** Rotate right and print sensor values */
    cout << "Rotating right..." << endl;
    robotino->rotate(RIGHT);
    Sleep(2000);
    robotino->stop();
    irSensor.update();
    printSensorValues(&irSensor);

    /** Disconnect from the robot */
    cout << "Disconnecting from robot..." << endl;
    robotino->disconnect();

    /** Clean up */
    delete robotino;

    return 0;
}