/**
 * @file RobotControler.h
 * @brief Declaration of the RobotControler class.
 * @details This class manages robot movements and connection status using various interfaces and operators.
 * It allows for adding and updating sensors, as well as controlling access to its functions.
 * @author Elif Fatma Cebeci (152120221123@ogrenci.ogu.edu.tr)
 * @date December 2024
 */

#ifndef ROBOTCONTROLER_H
#define ROBOTCONTROLER_H

#include "SensorInterface.h"
#include "RobotInterface.h"
#include "RobotOperator.h"
#include <list>

using namespace std;

/**
 * @class RobotControler
 * @brief Class for managing robot movements and connection status.
 */
class RobotControler {
private:
    list<SensorInterface*> sensorList; ///< List of sensor interfaces.
    RobotInterface* robot; ///< Pointer to the robot interface.
    RobotOperator* robotOperator; ///< Object to control the robot operator.
    bool accessC; ///< Boolean indicating access control status.

public:
    /**
     * @brief Constructor for RobotControler.
     * @param sensorlist List of sensor interfaces.
     * @param robot Pointer to the robot interface.
     * @param robotOperator Object to control the robot operator.
     */
    RobotControler(list<SensorInterface*> sensorlist, RobotInterface* robot, RobotOperator* robotOperator);

    /**
     * @brief Destructor for RobotControler.
     */
    ~RobotControler();

    /**
     * @brief Rotates the robot to the left.
     */
    void turnLeft();

    /**
     * @brief Rotates the robot to the right.
     */
    void turnRight();

    /**
     * @brief Moves the robot forward.
     */
    void moveForward();

    /**
     * @brief Moves the robot backward.
     */
    void moveBackward();

    /**
     * @brief Moves the robot to the left.
     */
    void moveLeft();

    /**
     * @brief Moves the robot to the right.
     */
    void moveRight();

    /**
     * @brief Stops the robot's motion.
     */
    void stop();

    /**
     * @brief Retrieves the current pose of the robot (x, y, and theta).
     * @return The current pose of the robot as a Pose object.
     */
    Pose getPose();

    /**
     * @brief Prints the status and position of the robot.
     */
    void print();

    /**
     * @brief Connects the robot to the FestoRobotAPI.
     * @return True if the connection is successful, false otherwise.
     */
    bool connectRobot();

    /**
     * @brief Disconnects the robot from the FestoRobotAPI.
     * @return False to indicate the robot is disconnected.
     */
    bool disconnectRobot();

    /**
     * @brief Adds a sensor to the list of sensors.
     * @param sensor Pointer to the sensor object to add.
     */
    void addSensor(SensorInterface* sensor);

    /**
     * @brief Updates all sensors in the list.
     */
    void updateSensors();

    /**
     * @brief Opens access for the RobotControler functions.
     * Allows functions to execute if the correct access code is provided.
     * @param access The access code to validate.
     * @return True if the access code is correct and access is granted, false otherwise.
     */
    bool openAccess(int access);

    /**
     * @brief Closes access for the RobotControler functions.
     * Prevents functions from executing until access is reopened.
     * @param access The access code to validate.
     * @return True if the access is successfully closed, false otherwise.
     */
    bool closeAccess(int access);
};

#endif // ROBOTCONTROLER_H
