/*
#include "SafeNavigation.h"
#include "RobotControler.h"
#include "SensorInterface.h" // Include SensorInterface header
#include <iostream>
#include <vector>
#include <list>

using namespace std;


class MockRobotControler : public RobotControler {
public:
    MockRobotControler()
        : RobotControler(list<SensorInterface*>(), nullptr, ()) {} // Pass empty list and default values


    void moveForward() {
        std::cout << "Robot is moving forward." << std::endl;
    }

    void moveBackward() {
        std::cout << "Robot is moving backward." << std::endl;
    }


    void stop() {
        std::cout << "Robot has stopped." << std::endl;
    }
};


class MockSensorInterface : public SensorInterface {
private:
    double ranges[9];

public:
    MockSensorInterface() {
        for (int i = 0; i < 9; ++i) {
            ranges[i] = 1.0; // Initialize all ranges to 1.0
        }
    }

    void update() override {
        // No actual logic needed for the mock implementation
    }

    double getSensorValue(int index) const override {
        if (index >= 0 && index < 9) {
            return ranges[index];
        }
        return 0.0; // Return 0.0 for out-of-bounds indices
    }

    void setSensorValue(int index, double value) {
        if (index >= 0 && index < 9) {
            ranges[index] = value;
        }
    }
};


int main() {
    // Create mock objects
    MockRobotControler mockController;
    MockSensorInterface mockSensor; // Create mock sensor

    // Create SafeNavigation instance
    SafeNavigation safeNav(&mockController, &mockSensor);

    // Test moveForwardSafe when no obstacles are detected
    std::cout << "Testing moveForwardSafe with no obstacles..." << std::endl;
    safeNav.moveForwardSafe();

    // Simulate an obstacle (set range below threshold)
    mockSensor.setSensorValue(4, 0.4);
    std::cout << "Testing moveForwardSafe with an obstacle..." << std::endl;
    safeNav.moveForwardSafe();

    // Test moveBackwardSafe with no obstacles
    mockSensor.setSensorValue(4, 1.0); // Clear obstacle
    std::cout << "Testing moveBackwardSafe with no obstacles..." << std::endl;
    safeNav.moveBackwardSafe();

    // Simulate an obstacle while moving backward
    mockSensor.setSensorValue(2, 0.3);
    std::cout << "Testing moveBackwardSafe with an obstacle..." << std::endl;
    safeNav.moveBackwardSafe();

    std::cout << "All tests completed." << std::endl;
    return 0;
}
*/