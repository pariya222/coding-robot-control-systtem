#ifndef IRSENSOR_H
#define IRSENSOR_H

#include "FestoRobotSensorInterface.h"
#include <string>

/**
 * @class IRSensor
 * @brief Infrared sensor class derived from FestoRobotSensorInterface.
 *
 * This class encapsulates functionality for interacting with an infrared sensor.
 * It provides methods for updating sensor readings, retrieving range values,
 * and accessing specific sensor information.
 *
 * @date December 2024
 * @author Mervenur �akmako�lu (152120221128@ogrenci.ogu.edu.tr)
 */
class IRSensor : public FestoRobotSensorInterface {
private:
    double ranges[9]; //!< Array to store the sensor readings.

public:
    /**
     * @brief Constructor for the IRSensor class.
     *
     * Initializes the infrared sensor and sets up the necessary API interface
     * for retrieving sensor data.
     *
     * @param api A pointer to the robot's API for interacting with the hardware.
     */
    explicit IRSensor(FestoRobotAPI* api);

    /**
     * @brief Destructor for the IRSensor class.
     *
     * Cleans up resources and handles any necessary teardown when the sensor
     * object is destroyed.
     */
    ~IRSensor();

    /**
     * @brief Updates the sensor readings.
     *
     * Retrieves the latest range data from the infrared sensor through the
     * robot's API and stores it in the `ranges` array.
     */
    virtual  void update();

    /**
     * @brief Gets the range value at a specific index.
     *
     * This function retrieves the distance reading from the sensor array at the
     * specified index (0 to 8). Returns 0.0 if the index is out of bounds.
     *
     * @param index The index of the range value (0 to 8).
     * @return The range value at the given index (or 0.0 if out of bounds).
     */
    virtual double getRange(int index) const;

    /**
     * @brief Overloaded operator[] to access range values.
     *
     * Provides array-like access to the range values. This operator allows
     * you to access sensor readings as you would with an array.
     *
     * @param index The index of the range value (0 to 8).
     * @return The range value at the given index (or 0.0 if out of bounds).
     */
    virtual double operator[](int index) const;

    /**
     * @brief Gets the sensor type.
     *
     * This method returns a string representing the sensor type. For this class,
     * it will always return `"IR"` for infrared.
     *
     * @return A string representing the sensor type ("IR").
     */
    virtual std::string getSensorType() const;

    /**
     * @brief Gets the sensor value at a specific index.
     *
     * This method retrieves the sensor value at the specified index from the
     * sensor array. It can be used to access the specific readings from the
     * sensor data.
     *
     * @param index The index of the sensor reading to retrieve (0 to 8).
     * @return The sensor value at the specified index.
     */
    virtual double getSensorValue(int index) const;
};

#endif // IRSENSOR_H
