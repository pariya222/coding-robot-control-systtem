/**
 * @file MotionMenu.cpp
 * @brief Implementation of the MotionMenu class for controlling robot motion.
 * @date december 2024
 * @Author Pariya Jahanbakhsh  (152120231154@ogrenci.ogu.edu.tr)
 */

#include "MotionMenu.h"
#include <iostream>
#include <thread>
#include <chrono>
#include <limits>

using namespace std;

/**
 * @brief Constructs a MotionMenu object.
 * @param control Pointer to the RobotControler instance.
 * @param safeNav Pointer to the SafeNavigation instance.
 * @param Choice Initial choice selection for the menu.
 */
MotionMenu::MotionMenu(RobotControler* control, SafeNavigation* safeNav, int Choice)
    : Control(control), SafeNav(safeNav), choice(Choice) {}
/**
 * @brief Displays the motion menu and processes user choices.
 */
void MotionMenu::showMenu() {
    do {
        cout << endl;
        cout << "    Motion Menu    \n";
        cout << "1. Move forward" << endl;
        cout << "2. Move backward" << endl;
        cout << "3. Move left" << endl;
        cout << "4. Move right" << endl;
        cout << "5. Safe Move forward" << endl;
        cout << "6. Safe Move backward" << endl;
        cout << "7. Turn left" << endl;
        cout << "8. Turn right" << endl;
        cout << "9. Move distance" << endl;
        cout << "10. Quit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        if (cin.fail()) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input! Please enter a number." << endl;
            choice = -1; // Set to invalid choice
        }

        ExecuteChoice();
    } while (choice != 10);
}

/**
 * @brief Executes the chosen motion command based on the user's input.
 */
void MotionMenu::ExecuteChoice() {
    if (!Control || !SafeNav) {
        cout << "Control or Safe Navigation is not initialized." << endl;
        return;
    }

    switch (choice) {
    case 1:
        Control->moveForward();
        cout << "Robot moved forward!" << endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(2000));
        Control->stop();
        break;
    case 2:
        Control->moveBackward();
        cout << "Robot moved backward!" << endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(2000));
        Control->stop();
        break;
    case 3:
        Control->moveLeft();
        cout << "Robot moved left!" << endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(2000));
        Control->stop();
        break;
    case 4:
        Control->moveRight();
        cout << "Robot moved right!" << endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(2000));
        Control->stop();
        break;
    case 5:
        SafeNav->moveForwardSafe();
        cout << "Safe Move Robot activated!" << endl;
        break;
    case 6:
        SafeNav->moveBackwardSafe();
        cout << "Safe Move Robot activated!" << endl;
        break;
    case 7:
        Control->turnLeft();
        cout << "Robot turned left!" << endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
        Control->stop();
        break;
    case 8:
        Control->turnRight();
        cout << "Robot turned right!" << endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
        Control->stop();
        break;
    case 9: {
        double distance;
        cout << "Enter the distance to move: ";
        cin >> distance;
        if (cin.fail() || distance <= 0) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid distance. Please enter a positive number." << endl;
            break;
        }
        Control->moveForward();
        std::this_thread::sleep_for(std::chrono::milliseconds(static_cast<int>(distance * 1000)));
        Control->stop();
        cout << "Robot moved " << distance << " units." << endl;
        break;
    }
    case 10:
        cout << "Exiting the menu." << endl;
        break;
    default:
        cout << "Invalid choice! Please select a valid option." << endl;
        break;
    }
}
