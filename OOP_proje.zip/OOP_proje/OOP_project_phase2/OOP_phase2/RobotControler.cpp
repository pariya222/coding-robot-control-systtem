/**
 * @file RobotControler.cpp
 * @brief Implementation of the RobotControler class for managing robot movements and connection status.
 * @details This class manages robot movements and connection status using various interfaces and operators.
 * It allows for adding and updating sensors, as well as controlling access to its functions.
 * @author Elif Fatma Cebeci (152120221123@ogrenci.ogu.edu.tr)
 * @date December 2024
 */

#include "RobotControler.h" 
#include "SensorInterface.h" 
#include "RobotInterface.h" 
#include <iostream> 
#include <list> 
#include "RobotOperator.h"
using namespace std;

/**
 * @brief Constructor for the RobotControler class.
 * @param sensorlist List of sensor interfaces.
 * @param robot Pointer to the robot interface.
 * @param robotOperator Object to control the robot operator.
 */
RobotControler::RobotControler(list<SensorInterface*> sensorlist, RobotInterface* robot, RobotOperator* robotOperator) :
    sensorList(sensorlist), robot(robot), robotOperator(robotOperator), accessC(false) { }

/**
 * @brief Destructor for the RobotControler class.
 * Deletes the dynamically allocated Pose and FestoRobotAPI objects.
 */
RobotControler::~RobotControler() {}

/**
 * @brief Rotates the robot to the left.
 * Executes the operation only if the robot is connected.
 */
void RobotControler::turnLeft() {
    if (robot && accessC) {
        robot->turnLeft();
    }
}

/**
 * @brief Rotates the robot to the right.
 * Executes the operation only if the robot is connected.
 */
void RobotControler::turnRight() {
    if (robot && accessC) {
        robot->turnRight();
    }
}

/**
 * @brief Moves the robot forward.
 * Executes the operation only if the robot is connected.
 */
void RobotControler::moveForward() {
    if (robot && accessC) {
        robot->moveForward();
    }
}

/**
 * @brief Moves the robot backward.
 * Executes the operation only if the robot is connected.
 */
void RobotControler::moveBackward() {
    if (robot && accessC) {
        robot->moveBackward();
    }
}

/**
 * @brief Moves the robot to the left.
 * Executes the operation only if the robot is connected.
 */
void RobotControler::moveLeft() {
    if (robot && accessC) {
        robot->moveLeft();
    }
}

/**
 * @brief Moves the robot to the right.
 * Executes the operation only if the robot is connected.
 */
void RobotControler::moveRight() {
    if (robot && accessC) {
        robot->moveRight();
    }
}

/**
 * @brief Stops the robot's motion.
 * Executes the operation only if the robot is connected.
 */
void RobotControler::stop() {
    if (robot && accessC) {
        robot->stop();
    }
}

/**
 * @brief Retrieves the current pose of the robot (x, y, and theta).
 * @return The current pose of the robot as a Pose object.
 */
Pose RobotControler::getPose() {
    if (robot && accessC) {
        return (robot->getPose());
    }
    return Pose();
}

/**
 * @brief Prints the status and position of the robot.
 * Displays whether the robot is connected and its current pose (x, y, theta).
 */
void RobotControler::print() {
    if (robot && accessC) {
        cout << "Robot is open" << endl;
        robot->print();
    }
    else {
        cout << "Robot is not open" << endl;
    }
}

/**
 * @brief Connects the robot to the FestoRobotAPI.
 * @return True if the connection is successful, false otherwise.
 */
bool RobotControler::connectRobot() {
    if (robot && accessC) {
        robot->connectRobot();
        return true;
    }
    return false;
}

/**
 * @brief Disconnects the robot from the FestoRobotAPI.
 * Frees the memory allocated for the robotAPI object and resets the pointer.
 * @return False to indicate the robot is disconnected.
 */
bool RobotControler::disconnectRobot() {
    if (robot && accessC) {
        robot->disconnectRobot();
        return false;
    }
    return false;
}

/**
 * @brief Adds a sensor to the list of sensors.
 * @param sensor Pointer to the sensor object to add.
 */
void RobotControler::addSensor(SensorInterface* sensor) {
    if (accessC) {
        sensorList.push_back(sensor);
    }
}

/**
 * @brief Updates all sensors in the list.
 * Calls the update function on all sensor objects in the list.
 */
void RobotControler::updateSensors() {
    if (accessC) {
        for (auto& sensor : sensorList) {
            sensor->update();
        }
    }
}

/**
 * @brief Opens access for the RobotControler functions.
 * Allows functions to execute if the correct password is provided.
 * @param access The access code to validate.
 * @return True if the access code is correct and access is granted, false otherwise.
 */
bool RobotControler::openAccess(int access) {
    if (robotOperator->checkAccessCode(access)) {
        accessC = true;
        return true;
    }
    return false;
}

/**
 * @brief Closes access for the RobotControler functions.
 * Prevents functions from executing until access is reopened.
 * @param access The access code to validate.
 * @return True if the access is successfully closed, false otherwise.
 */
bool RobotControler::closeAccess(int access) {
    if (robotOperator->checkAccessCode(access)) {
        accessC = false;
        return true;
    }
    return false;
}
