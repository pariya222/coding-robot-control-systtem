/**
 * @file NewMenu.cpp
 * @brief Implementation of the RobotMenu class
 * @details This file contains the implementation of the RobotMenu class, which provides
 * a menu system for interacting with the RobotControler and RobotOperator.
 * @author Elif Fatma Cebeci (152120221123@ogrenci.ogu.edu.tr)
 * @date December, 2024
 */

#include "RobotMenu.h"
#include "SafeNavigation.h"
#include "RobotControler.h"
#include "RobotOperator.h"
#include <iostream>

using namespace std;

/**
 * @brief Constructs a RobotMenu object with the given RobotControler, RobotOperator, and SafeNavigation.
 * @param controller A pointer to the RobotControler instance.
 * @param robotOperator A pointer to the RobotOperator instance.
 * @param safeNav A pointer to the SafeNavigation instance.
 */
RobotMenu::RobotMenu(RobotControler* controller, RobotOperator* robotOperator, SafeNavigation* safeNav)
    : controller(controller), robotOperator(robotOperator), safeNav(safeNav) {}

/**
 * @brief Displays the main menu and handles user input.
 */
void RobotMenu::displayMenu() {
    int choice;
    do {
        cout << "\n=== Robot Menu ===" << endl;
        cout << "1. Move Robot" << endl;
        cout << "2. Manage Connection" << endl;
        cout << "3. Update Sensors" << endl;
        cout << "4. Print Status" << endl;
        cout << "5. Operator Access" << endl;
        cout << "6. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            moveRobot();
            break;
        case 2:
            manageConnection();
            break;
        case 3:
            updateSensors();
            break;
        case 4:
            printStatus();
            break;
        case 5:
            operatorAccess();
            break;
        case 6:
            cout << "Exiting menu..." << endl;
            break;
        default:
            cout << "Invalid choice, please try again." << endl;
        }
    } while (choice != 6);
}

/**
 * @brief Handles the movement of the robot based on user input.
 */
void RobotMenu::moveRobot() {
    int direction;
    cout << "\n=== Move Robot ===" << endl;
    cout << "1. Move Forward" << endl;
    cout << "2. Move Backward" << endl;
    cout << "3. Move Forward Safely" << endl;
    cout << "4. Move Backward Safely" << endl;
    cout << "5. Turn Left" << endl;
    cout << "6. Turn Right" << endl;
    cout << "7. Move Left" << endl;
    cout << "8. Move Right" << endl;
    cout << "9. Stop" << endl;
    cout << "Enter your choice: ";
    cin >> direction;

    switch (direction) {
    case 1:
        controller->moveForward();
        break;
    case 2:
        controller->moveBackward();
        break;
    case 3:
        safeNav->moveForwardSafe();
        cout << "Safe Move Robot activated!" << endl;
        break;
    case 4:
        safeNav->moveBackwardSafe();
        cout << "Safe Move Robot activated!" << endl;
        break;
    case 5:
        controller->turnLeft();
        break;
    case 6:
        controller->turnRight();
        break;
    case 7:
        controller->moveLeft();
        break;
    case 8:
        controller->moveRight();
        break;
    case 9:
        controller->stop();
        break;
    default:
        cout << "Invalid choice, please try again." << endl;
    }
}

/**
 * @brief Manages the connection of the robot based on user input.
 */
void RobotMenu::manageConnection() {
    int choice;
    cout << "\n=== Manage Connection ===" << endl;
    cout << "1. Connect Robot" << endl;
    cout << "2. Disconnect Robot" << endl;
    cout << "Enter your choice: ";
    cin >> choice;

    switch (choice) {
    case 1:
        if (controller->connectRobot()) {
            cout << "Robot connected successfully." << endl;
        }
        else {
            cout << "Failed to connect robot." << endl;
        }
        break;
    case 2:
        if (controller->disconnectRobot()) {
            cout << "Robot disconnected successfully." << endl;
        }
        else {
            cout << "Failed to disconnect robot." << endl;
        }
        break;
    default:
        cout << "Invalid choice, please try again." << endl;
    }
}

/**
 * @brief Updates the sensors of the robot.
 */
void RobotMenu::updateSensors() {
    cout << "\nUpdating sensors..." << endl;
    controller->updateSensors();
    cout << "Sensors updated." << endl;
}

/**
 * @brief Prints the status of the robot.
 */
void RobotMenu::printStatus() {
    cout << "\n=== Robot Status ===" << endl;
    controller->print();
}

/**
 * @brief Handles operator access based on user input.
 */
void RobotMenu::operatorAccess() {
    int accessCode;
    cout << "\nEnter access code: ";
    cin >> accessCode;

    if (controller->openAccess(accessCode)) {
        cout << "Access granted." << endl;
    }
    else {
        cout << "Access denied." << endl;
    }

    robotOperator->print();
}
