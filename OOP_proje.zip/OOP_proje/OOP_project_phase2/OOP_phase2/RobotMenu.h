/**
 * @file NewMenu.h
 * @brief Declaration of the RobotMenu class
 * @details This class provides a menu system to interact with the RobotControler and RobotOperator.
  * @author Elif Fatma (152120221123@ogrenci.ogu.edu.tr)
 * @date December, 2024
 */

#ifndef ROBOTMENU_H
#define ROBOTMENU_H

#include "RobotControler.h"
#include "RobotOperator.h"
#include <iostream>
#include <string>
#include "SafeNavigation.h"
using namespace std;

/**
 * @class RobotMenu
 * @brief A class to provide a menu system for interacting with the robot controller and operator.
 */
class RobotMenu {
public:
    /**
     * @brief Constructor for RobotMenu
     * @param controller Pointer to the RobotControler object
     * @param operator Pointer to the RobotOperator object
     */
    RobotMenu(RobotControler* controller, RobotOperator* robotOperator, SafeNavigation* SafeNav);

    /**
     * @brief Displays the menu and handles user input
     */
    void displayMenu();

private:
    RobotControler* controller; ///< Pointer to the robot controller
    RobotOperator* robotOperator; ///< Pointer to the robot operator
    SafeNavigation* safeNav;
    void moveRobot();
    void manageConnection();
    void updateSensors();
    void printStatus();
    void operatorAccess();
};

#endif  // ROBOTMENU_H
