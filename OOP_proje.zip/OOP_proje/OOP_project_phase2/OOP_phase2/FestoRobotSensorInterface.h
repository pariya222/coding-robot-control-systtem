/**
 * @file FestoRobotSensorInterface.h
 * @brief Declaration of the FestoRobotSensorInterface class.
 * @details This class interfaces with the FestoRobotAPI to interact with the robot sensors.
 * @author Elif Fatma Cebeci (152120221123@ogrenci.ogu.edu.tr)
 * @date December 2024
 */

#ifndef FESTOROBOTSENSORINTERFACE_H
#define FESTOROBOTSENSORINTERFACE_H

#include "FestoRobotAPI.h"
#include "SensorInterface.h"

 /**
  * @class FestoRobotSensorInterface
  * @brief Interface class for controlling the Festo robot sensors.
  */
class FestoRobotSensorInterface : public SensorInterface {
protected:
    FestoRobotAPI* robotAPI; ///< Pointer to the robot API.

public:
    /**
     * @brief Constructor for FestoRobotSensorInterface
     * @param api Pointer to the FestoRobotAPI object
     */
    FestoRobotSensorInterface(FestoRobotAPI* api) : robotAPI(api) {}

    /**
     * @brief Virtual destructor for FestoRobotSensorInterface
     */
    virtual ~FestoRobotSensorInterface() {}

    // Other member functions can be declared here
};

#endif // FESTOROBOTSENSORINTERFACE_H
