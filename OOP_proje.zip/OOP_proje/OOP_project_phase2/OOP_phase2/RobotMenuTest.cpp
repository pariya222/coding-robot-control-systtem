/**
 * @file RobotMenuTest.cpp
 * @brief Main test file for the RobotMenu system.
 * @author Elif Fatma Cebeci (152120221123@ogrenci.ogu.edu.tr)
 * @date December, 2024
 */

#include "RobotMenu.h"
#include "FestoRobotAPI.h"
#include "IRSensor.h"
#include "RobotControler.h"
#include "RobotOperator.h"
#include <iostream>
#include <list>
#include <string>
#include "SensorInterface.h"
#include "FestoRobotInterface.h"
#include "FestoRobotSensorInterface.h"
#include "LidarSensor.h"
#include "Pose.h"
#include "SafeNavigation.h"

using namespace std;

/**
 * @brief Main function to initialize and test the RobotMenu system.
 *
 * @return int Returns 0 upon successful execution.
 */
int main() {
    string name, surname;
    int accessCode;

    cout << "Enter operator's first name: ";
    cin >> name;

    cout << "Enter operator's last name: ";
    cin >> surname;

    cout << "Enter operator's access code (4-digit): ";
    cin >> accessCode;

    // Initialize sensors
    list<SensorInterface*> sensors;
    FestoRobotAPI* api = new FestoRobotAPI();
    IRSensor* irSensor = new IRSensor(api);
    LidarSensor* lidarSensor = new LidarSensor(api);
    sensors.push_back(irSensor);
    sensors.push_back(lidarSensor);

    // Initialize robot and controller
    FestoRobotInterface* robot = new FestoRobotInterface();
    RobotOperator* operator1 = new RobotOperator(name, surname, accessCode);
    RobotControler* robotController = new RobotControler(sensors, robot, operator1);
    SafeNavigation* safeNav = new SafeNavigation(robotController, irSensor);

    // Create and run RobotMenu
    RobotMenu* robotMenu = new RobotMenu(robotController, operator1, safeNav);
    robotMenu->displayMenu(); ///< Display the RobotMenu to interact with the robot system

    // Clean up memory
    delete robotController;
    delete operator1;
    delete irSensor;
    delete lidarSensor;
    delete api;
    delete robot;
    delete safeNav;
    delete robotMenu;

    return 0;
}
