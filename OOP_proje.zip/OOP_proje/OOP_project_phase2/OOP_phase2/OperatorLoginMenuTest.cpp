/**
 * @file main.cpp
 * @brief Main program to demonstrate robot and sensor operations.
 * @details This program initializes the robot API, sensors, and robot controller, allowing the user to connect to a robot, retrieve sensor data, and display the robot's pose.
 * @author R�meysa �elik (152120211125@ogrenci.ogu.edu.tr)
 * @date December 2024
 */

#include <iostream>
#include <list>
#include <Windows.h>  // For DWORD and Windows API definitions
#include "RobotControler.h"
#include "FestoRobotAPI.h"
#include "IRSensor.h"
#include "LidarSensor.h"
#include "RobotOperator.h"

using namespace std;

/**
 * @brief Main entry point of the program.
 *
 * This function performs the following operations:
 * - Initializes the robot API, sensors, and robot controller.
 * - Demonstrates connecting to the robot.
 * - Retrieves and displays the robot's pose and sensor data.
 * - Disconnects the robot and cleans up memory.
 *
 * @return int Exit status of the program (0 for success).
 */
int main() {
    // Initialize the robot API
    FestoRobotAPI* robotAPI = new FestoRobotAPI();

    // Initialize the robot operator with example data
    RobotOperator robotOperator("John", "Doe", 1234);

    // Initialize the sensors
    IRSensor* irSensor = new IRSensor(robotAPI);
    LidarSensor* lidarSensor = new LidarSensor(robotAPI);

    // Create a sensor list and add sensors
    list<SensorInterface*> sensorList = { irSensor, lidarSensor };

    // Initialize the RobotController with the sensor list, robot API, and robot operator
    RobotControler* robotController = new RobotControler(sensorList, robotAPI, robotOperator);

    // Connect to the robot
    if (robotController->connectRobot()) {
        cout << "Robot connected successfully." << endl;
    }
    else {
        cout << "Failed to connect to the robot." << endl;
    }

    // Retrieve and display the robot's pose
    Pose currentPose = robotController->getPose();
    double x, y, th;
    currentPose.getPose(x, y, th);
    cout << "Current Pose - X: " << x << " Y: " << y << " Theta: " << th << endl;

    // Retrieve and display IR sensor data
    cout << "\nIR Sensor Data:" << endl;
    irSensor->update();
    for (int i = 0; i < 9; i++) {
        cout << "Sensor " << i << " Range: " << irSensor->getRange(i) << " meters." << endl;
    }

    // Retrieve and display Lidar sensor data
    cout << "\nLidar Sensor Data:" << endl;
    lidarSensor->update();
    int rangeNum = lidarSensor->getRangeNum();
    for (int i = 0; i < rangeNum; i++) {
        cout << "Angle: " << lidarSensor->getAngle(i) << " degrees, Range: " << lidarSensor->getRange(i) << " meters." << endl;
    }

    // Disconnect the robot
    robotController->disconnectRobot();
    cout << "Robot disconnected." << endl;

    // Clean up memory
    delete irSensor;
    delete lidarSensor;
    delete robotController;
    delete robotAPI;

    return 0;
}
