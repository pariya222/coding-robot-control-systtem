/**
 * @file RobotControlerTest.cpp
 * @brief Main file for testing RobotControler with various sensors and robot movements.
 * @details This file contains the main function which tests the RobotControler class using IRSensor and LidarSensor.
 * @author Elif Fatma (152120221123@ogrenci.ogu.edu.tr)
* @date December, 2024
 * @date December, 2024
 */

#include <iostream>
#include <list>
#include <thread>  // For sleep_for function
#include <chrono>  // For chrono::milliseconds
#include "RobotControler.h"
#include "SensorInterface.h"
#include "RobotOperator.h"
#include "FestoRobotInterface.h"
#include "FestoRobotSensorInterface.h"
#include "IRSensor.h"
#include "LidarSensor.h"
#include "Pose.h"

using namespace std;

/**
 * @brief Main function for testing RobotControler class.
 * @return int Returns 0 on successful execution.
 */
int main() {
    list<SensorInterface*> sensors;

    FestoRobotAPI api;
    IRSensor* irSensor = new IRSensor(&api);
    LidarSensor* lidarSensor = new LidarSensor(&api);
    sensors.push_back(irSensor);
    sensors.push_back(lidarSensor);

    FestoRobotInterface* robot = new FestoRobotInterface();
    RobotOperator* operator1 = new RobotOperator("John", "Doe", 1234);

    RobotControler controller(sensors, robot, operator1);

    // Test access control
    if (controller.openAccess(1234)) {
        cout << "Access opened" << endl;
    }
    else {
        cout << "Access denied" << endl;
    }

    // Test robot connection
    if (controller.connectRobot()) {
        cout << "Robot connected successfully" << endl;
    }

    // Test robot movements
    controller.moveForward();
    this_thread::sleep_for(chrono::milliseconds(500));  // 500 milliseconds delay
    controller.turnLeft();
    this_thread::sleep_for(chrono::milliseconds(500));
    controller.moveBackward();
    this_thread::sleep_for(chrono::milliseconds(500));
    controller.turnRight();
    this_thread::sleep_for(chrono::milliseconds(500));
    controller.moveLeft();
    this_thread::sleep_for(chrono::milliseconds(500));
    controller.moveRight();
    this_thread::sleep_for(chrono::milliseconds(500));
    controller.stop();
    this_thread::sleep_for(chrono::milliseconds(500));

    // Test pose and print
    Pose pose = controller.getPose();
    controller.print();

    // Test sensor update
    controller.updateSensors();
    cout << "IR Sensor Type: " << irSensor->getSensorType() << endl;
    cout << "IR Sensor Value[0]: " << irSensor->getSensorValue(0) << endl;

    cout << "Lidar Sensor Type: " << lidarSensor->getSensorType() << endl;
    cout << "Lidar Sensor Value[0]: " << lidarSensor->getSensorValue(0) << endl;

    // Test robot disconnection
    if (controller.disconnectRobot()) {
        cout << "Robot disconnected successfully" << endl;
    }

    // Close access
    if (controller.closeAccess(1234)) {
        cout << "Access closed" << endl;
    }

    // Memory management
    delete robot;
    delete operator1;
    for (auto& sensor : sensors) {
        delete sensor;
    }

    return 0;
}
