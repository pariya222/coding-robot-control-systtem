/**
 * @file OperatorLoginMenu.cpp
 * @brief Implementation of the OperatorLoginMenu class
 * @details This class handles the operator login functionality.
 */

#include "OperatorLoginMenu.h"
#include <iostream>
#include <string>

using namespace std;

/**
 * @brief Constructor for the OperatorLoginMenu class
 * @param operatorList List of operators
 */
OperatorLoginMenu::OperatorLoginMenu(const std::vector<RobotOperator>& operatorList)
    : operators(operatorList), loggedInOperator(nullptr) {}

/**
 * @brief Finds an operator by their first name.
 *
 * @param name The first name of the operator.
 * @return Pointer to the RobotOperator object if found, otherwise nullptr.
 */
RobotOperator* OperatorLoginMenu::findOperatorByName(const std::string& name) {
    for (auto& op : operators) {
        // Directly accessing name field of RobotOperator
        if (op.name == name) {
            return &op;
        }
    }
    return nullptr;
}

/**
 * @brief Finds an operator by their surname.
 *
 * @param surname The surname of the operator.
 * @return Pointer to the RobotOperator object if found, otherwise nullptr.
 */
RobotOperator* OperatorLoginMenu::findOperatorBySurname(const std::string& surname) {
    for (auto& op : operators) {
        // Directly accessing surname field of RobotOperator
        if (op.surname == surname) {
            return &op;
        }
    }
    return nullptr;
}

/**
 * @brief Displays the login menu and handles the operator login process.
 *
 * This function collects the operator's first name, surname, and access code.
 * It validates the input and logs in the operator if the credentials match.
 * If any of the credentials are incorrect, an error message is displayed.
 */
void OperatorLoginMenu::showLoginMenu() {
    string name, surname;
    string accessCodeInput;

    cout << "-----------------------------------------------\n";
    cout << "Welcome to Webots Robot Control Application\n";
    cout << "-----------------------------------------------\n";
    cout << "Operator Login Menu\n";
    cout << "--------------------\n";

    cout << "Please enter your first name: ";
    getline(cin, name);

    RobotOperator* operatorByName = findOperatorByName(name);
    if (!operatorByName) {
        cout << "Error: Operator with this name not found.\n";
        return;
    }

    cout << "Please enter your surname: ";
    getline(cin, surname);

    RobotOperator* operatorBySurname = findOperatorBySurname(surname);
    if (!operatorBySurname || operatorByName != operatorBySurname) {
        cout << "Error: Operator with this name and surname not found.\n";
        return;
    }

    RobotOperator* operatorToLogin = operatorByName;

    do {
        cout << "Please enter your access code: ";

        // Securely capture access code
        char ch;
        accessCodeInput.clear();
        while ((ch = getchar()) != '\n' && ch != EOF) {
            if (isdigit(ch)) {
                accessCodeInput += ch;
                cout << '*'; // Mask input
            }
        }
        cout << endl;

        if (accessCodeInput.length() != 4) {
            cout << "Error: Access code must be a 4-digit integer. Please try again.\n";
        }
    } while (accessCodeInput.length() != 4);

    int accessCode;
    try {
        accessCode = stoi(accessCodeInput);
    }
    catch (const std::exception&) {
        cout << "Error: Invalid access code input.\n";
        return;
    }

    // Check if the access code is correct
    if (operatorToLogin->checkAccessCode(accessCode)) {
        loggedInOperator = operatorToLogin;
        cout << "Operator authorized. Access granted.\n";
        displayLoggedInOperatorDetails();
    }
    else {
        cout << "Error: Invalid access code.\n";
    }
}

/**
 * @brief Logs out the currently logged-in operator.
 *
 * If no operator is logged in, an appropriate message is displayed.
 */
void OperatorLoginMenu::logout() {
    if (isLoggedIn()) {
        cout << "Operator " << loggedInOperator->name << " " << loggedInOperator->surname << " logged out.\n";
        loggedInOperator = nullptr;
    }
    else {
        cout << "No operator is currently logged in.\n";
    }
}

/**
 * @brief Checks if any operator is currently logged in.
 *
 * @return true if an operator is logged in, false otherwise.
 */
bool OperatorLoginMenu::isLoggedIn() const {
    return loggedInOperator != nullptr;
}

/**
 * @brief Displays the details of the currently logged-in operator.
 *
 * If no operator is logged in, an appropriate message is displayed.
 */
void OperatorLoginMenu::displayLoggedInOperatorDetails() const {
    if (isLoggedIn()) {
        cout << "Operator Information:\n";
        cout << "Name: " << loggedInOperator->name << "\n";
        cout << "Surname: " << loggedInOperator->surname << "\n";
        cout << "Access State: Granted\n";
    }
    else {
        cout << "No operator is logged in.\n";
    }
}

/**
 * @brief Returns the currently logged-in operator.
 *
 * @return Pointer to the logged-in RobotOperator object.
 */
RobotOperator* OperatorLoginMenu::getLoggedInOperator() const {
    return loggedInOperator;
}
