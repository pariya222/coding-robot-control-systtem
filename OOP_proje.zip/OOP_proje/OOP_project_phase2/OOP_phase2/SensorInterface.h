#ifndef SENSOR_INTERFACE_H
#define SENSOR_INTERFACE_H

#include <string>

class SensorInterface {
protected:
    std::string sensorType;

public:
    virtual ~SensorInterface() = default;
    virtual void update() = 0;
    virtual std::string getSensorType() const {
        return sensorType;
    }
    virtual double getSensorValue(int index) const = 0;
};

#endif // SENSOR_INTERFACE_H
