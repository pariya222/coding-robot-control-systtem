/**
* @file FestoRobotSensorInterface.h
* @brief Declaration of the FestoRobotSensorInterface class.
* @details This class interfaces with the FestoRobotAPI to interact with the robot sensors.
* @author R�meysa �elik(152120211125@ogrenci.ogu.edu.tr)
* @date December 2024
*/
#include <iostream>
#include <iomanip>
#include "SensorMenu.h"
#include "Pose.h"
#include <limits>

using namespace std;

/**
 * @brief Constructor for the SensorMenu class.
 *
 * Initializes the IR sensor and Lidar sensor, and adds them to the robot controller.
 *
 * @param control Pointer to the RobotControler object.
 * @param api Pointer to the FestoRobotAPI object.
 */
SensorMenu::SensorMenu(RobotControler* control, FestoRobotAPI* api)
    : Control(control), robotAPI(api) {
    irSensor = new IRSensor(robotAPI);
    lidarSensor = new LidarSensor(robotAPI);
    Control->addSensor(irSensor);
    Control->addSensor(lidarSensor);
}

/**
 * @brief Destructor for the SensorMenu class.
 *
 * Cleans up allocated resources for IR and Lidar sensors.
 */
SensorMenu::~SensorMenu() {
    delete irSensor;
    delete lidarSensor;
}

/**
 * @brief Displays the sensor menu and handles user interaction.
 */
void SensorMenu::showMenu() {
    do {
        cout << "\n=== Sensor Menu ===\n";
        cout << "1. Display Pose\n";
        cout << "2. Display IR Sensor Data\n";
        cout << "3. Display Lidar Sensor Data\n";
        cout << "4. Update All Sensors\n";
        cout << "5. Back to Main Menu\n";
        cout << "Enter your choice: ";

        // Validate user input
        if (!(cin >> sensorChoice)) {
            cin.clear(); // Clear error flag
            cin.ignore(10000, '\n'); // Ignore invalid input
            cout << "Invalid input. Please enter a number.\n";
            continue;
        }

        handleChoice();
    } while (sensorChoice != 5);
}

/**
 * @brief Handles the user's choice from the menu.
 *
 * Ensures the robot is connected before executing any sensor operation.
 */
void SensorMenu::handleChoice() {
    // Ensure robot is connected before proceeding with any sensor operation.
    if (!Control->connectRobot()) {
        cout << "The robot is off.\n";
        return;
    }

    switch (sensorChoice) {
    case 1:
        displayPose();
        break;
    case 2:
        displayIRSensorData();
        break;
    case 3:
        displayLidarSensorData();
        break;
    case 4:
        updateSensors();
        break;
    case 5:
        cout << "Returning to main menu...\n";
        break;
    default:
        cout << "Invalid choice. Please try again.\n";
        break;
    }
}

/**
 * @brief Displays the current pose of the robot.
 */
void SensorMenu::displayPose() {
    Pose currentPose = Control->getPose();
    double x, y, th;
    currentPose.getPose(x, y, th);

    cout << fixed << setprecision(2);
    cout << "\nRobot Pose:\n";
    cout << "X: " << x << " meters\n";
    cout << "Y: " << y << " meters\n";
    cout << "Theta: " << th << " degrees\n";
}

/**
 * @brief Displays data from the IR sensor.
 */
void SensorMenu::displayIRSensorData() {
    irSensor->update();
    cout << "\nIR Sensor Ranges:\n";
    for (int i = 0; i < 9; i++) {
        cout << "Sensor " << i << ": " << irSensor->getRange(i) << " meters\n";
    }
}

/**
 * @brief Displays data from the Lidar sensor.
 */
void SensorMenu::displayLidarSensorData() {
    lidarSensor->update();
    int rangeNum = lidarSensor->getRangeNum();
    if (rangeNum <= 0) {
        cout << "\nNo Lidar data available.\n";
        return;
    }

    cout << "\nLidar Sensor Ranges:\n";
    for (int i = 0; i < rangeNum; i++) {
        cout << "Angle: " << lidarSensor->getAngle(i)
            << " degrees, Range: " << lidarSensor->getRange(i) << " meters\n";
    }

    int maxIndex, minIndex;
    double maxRange = lidarSensor->getMax(maxIndex);
    double minRange = lidarSensor->getMin(minIndex);
    cout << "\nMaximum Range: " << maxRange << " meters at index " << maxIndex << "\n";
    cout << "Minimum Range: " << minRange << " meters at index " << minIndex << "\n";
}

/**
 * @brief Updates all sensors.
 */
void SensorMenu::updateSensors() {
    cout << "\nUpdating all sensors...\n";
    Control->updateSensors();
    cout << "All sensors have been updated.\n";
}
