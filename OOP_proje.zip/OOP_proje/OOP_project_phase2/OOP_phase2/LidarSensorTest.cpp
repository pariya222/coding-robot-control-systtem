/**
 * @file test_LidarSensorTest.cpp
 * @brief Main file for testing LidarSensor class.
 * @details This file contains the main function which tests the LidarSensor class using FestoRobotAPI.
 * @author Elif Fatma (152120221123@ogrenci.ogu.edu.tr)
 * @date December, 2024
 */

#include <iostream>
#include "FestoRobotAPI.h"
#include "LidarSensor.h"

using namespace std;

FestoRobotAPI* robotino;

/**
 * @brief Prints the sensor values for a given sensor.
 * @param sensor Pointer to the sensor interface.
 */
void printSensorValues(FestoRobotSensorInterface* sensor) {
    /** Print sensor type */
    cout << "Sensor Type: " << sensor->getSensorType() << endl;

    /** Print all sensor readings */
    for (int i = 0; i < 9; i++) {
        cout << "Sensor[" << i << "] = " << sensor->getSensorValue(i) << endl;
    }
    cout << "----------------------------------------------------------------------" << endl;
}

/**
 * @brief Main function for testing LidarSensor class.
 * @return int Returns 0 on successful execution.
 */
int main() {
    /** Create connection to robot */
    robotino = new FestoRobotAPI();

    /** Make connection to robot */
    robotino->connect();
    Sleep(2000);  // 2 seconds delay

    LidarSensor* lidarSensor = new LidarSensor(robotino);
    lidarSensor->update();

    // Test getRange and operator[]
    cout << "Lidar Sensor Ranges:" << endl;
    for (int i = 0; i < lidarSensor->getRangeNum(); i++) {
        cout << "Range[" << i << "]: " << lidarSensor->getRange(i) << endl;
    }

    // Test getMax
    int max1Index;
    double max1Range = lidarSensor->getMax(max1Index);
    cout << "Max Range: " << max1Range << " at index " << max1Index << endl;

    // Test getMin
    int min1Index;
    double min1Range = lidarSensor->getMin(min1Index);
    cout << "Min Range: " << min1Range << " at index " << min1Index << endl;

    // Test getAngle
    cout << "Lidar Sensor Angles:" << endl;
    for (int i = 0; i < lidarSensor->getRangeNum(); i++) {
        cout << "Angle[" << i << "]: " << lidarSensor->getAngle(i) << endl;
    }

    printSensorValues(lidarSensor);

    cout << "Moving backward..." << endl;
    robotino->move(BACKWARD);
    Sleep(2000);  // 2 seconds delay
    robotino->stop();
    lidarSensor->update();

    // Test getRange and operator[]
    cout << "Lidar Sensor Ranges:" << endl;
    for (int i = 0; i < lidarSensor->getRangeNum(); i++) {
        cout << "Range[" << i << "]: " << lidarSensor->getRange(i) << endl;
    }

    // Test getMax
    int maxIndex;
    double maxRange = lidarSensor->getMax(maxIndex);
    cout << "Max Range: " << maxRange << " at index " << maxIndex << endl;

    // Test getMin
    int minIndex;
    double minRange = lidarSensor->getMin(minIndex);
    cout << "Min Range: " << minRange << " at index " << minIndex << endl;

    // Test getAngle
    cout << "Lidar Sensor Angles:" << endl;
    for (int i = 0; i < lidarSensor->getRangeNum(); i++) {
        cout << "Angle[" << i << "]: " << lidarSensor->getAngle(i) << endl;
    }

    printSensorValues(lidarSensor);

    robotino->disconnect();

    /** Clean up */
    delete robotino;

    return 0;
}
