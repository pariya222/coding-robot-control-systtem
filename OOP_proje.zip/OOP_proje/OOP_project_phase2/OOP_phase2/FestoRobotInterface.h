/**
 * @file FestoRobotInterface.h
 * @author Mervenu�akmako�lu (152120221128@ogrenci.ogu.edu.tr)
 * @date December 2024
 * @brief Interface for controlling a Festo robot using the FestoRobotAPI.
 *
 * This class provides an abstraction layer for interacting with a Festo robot. It
 * implements the RobotInterface abstract class and uses the FestoRobotAPI for
 * robot control operations.
 */

#ifndef FESTO_ROBOT_INTERFACE_H
#define FESTO_ROBOT_INTERFACE_H

#include "RobotInterface.h"
#include "FestoRobotAPI.h"
#include "Pose.h"

 /**
  * @class FestoRobotInterface
  * @brief Interface for controlling a Festo robot using FestoRobotAPI.
  */
class FestoRobotInterface : public RobotInterface {
private:
    FestoRobotAPI* robotAPI; //!< Pointer to the FestoRobotAPI instance

public:
    /**
     * @brief Constructor.
     */
    FestoRobotInterface();

    /**
     * @brief Destructor.
     */
    ~FestoRobotInterface();

    /**
     * @brief Turns the robot to the left.
     */
    void turnLeft() override;

    /**
     * @brief Turns the robot to the right.
     */
    void turnRight() override;

    /**
     * @brief Moves the robot forward.
     */
    void moveForward() override;

    /**
     * @brief Moves the robot backward.
     */
    void moveBackward() override;

    /**
     * @brief Moves the robot to the left.
     */
    void moveLeft() override;

    /**
     * @brief Moves the robot to the right.
     */
    void moveRight() override;

    /**
     * @brief Stops the robot.
     */
    void stop() override;

    /**
     * @brief Retrieves the current pose of the robot.
     * @return The current pose as a Pose object.
     */
    Pose getPose() const ; 

    /**
     * @brief Prints the robot's current pose.
     */
    void print() const ;  


    /**
     * @brief Connects to the robot.
     * @return True if the connection was successful, false otherwise.
     */
    bool connectRobot() override;

    /**
     * @brief Disconnects from the robot.
     * @return True if the disconnection was successful, false otherwise.
     */
    bool disconnectRobot() override;
};

#endif // FESTO_ROBOT_INTERFACE_H
