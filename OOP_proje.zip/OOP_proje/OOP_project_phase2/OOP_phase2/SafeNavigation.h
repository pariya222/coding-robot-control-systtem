/**
 * @file SafeNavigation.h
 * @brief Header file for the SafeNavigation class.
 * @date december 2024
 * @Author Pariya Jahanbakhsh  (152120231154@ogrenci.ogu.edu.tr)
 */

#ifndef SAFENAVIGATION_H
#define SAFENAVIGATION_H

#include "RobotControler.h"
#include "SensorInterface.h"

 /**
  * @class SafeNavigation
  * @brief Provides safe navigation features for a robot, ensuring obstacle avoidance during movement.
  */
class SafeNavigation {
public:
    /**
     * @enum MOVESTATE
     * @brief Represents the current state of the robot's movement.
     */
    enum MOVESTATE {
        MOVING, ///< Robot is currently moving.
        STOP    ///< Robot is currently stopped.
    };

    /**
     * @brief Constructs a SafeNavigation object.
     * @param rc Pointer to the RobotControler instance.
     * @param sensor Pointer to the SensorInterface instance.
     */
    SafeNavigation(RobotControler* rc, SensorInterface* sensor);

    /**
     * @brief Moves the robot forward safely, avoiding obstacles.
     */
    void moveForwardSafe();

    /**
     * @brief Moves the robot backward safely, avoiding obstacles.
     */
    void moveBackwardSafe();

    /**
     * @brief Retrieves the current movement state of the robot.
     * @return The current MOVESTATE.
     */
    MOVESTATE getState() const;

private:
    RobotControler* controller;        ///< Pointer to the robot controller.
    SensorInterface* sensorInterface; ///< Pointer to the sensor interface.
    MOVESTATE state;                   ///< Current movement state.

    /**
     * @brief Checks for obstacles using the sensor interface.
     * @return True if an obstacle is detected, otherwise false.
     */
    bool isObstacleDetected();
};

#endif // SAFENAVIGATION_H