/**
 * @file SafeNavigation.cpp
 * @brief Implementation of the SafeNavigation class, providing obstacle-aware navigation for a robot.
 * @date December 2024
 * @Author Pariya Jahanbakhsh  (152120231154@ogrenci.ogu.edu.tr)
 */

#include "SafeNavigation.h"
#include <iostream>

using namespace std;

/**
 * @brief Constructor for SafeNavigation class.
 * @param rc Pointer to a RobotControler object for controlling the robot's movement.
 * @param sensor Pointer to a SensorInterface object for detecting obstacles.
 */
SafeNavigation::SafeNavigation(RobotControler* rc, SensorInterface* sensor)
    : controller(rc), sensorInterface(sensor), state(STOP) {}

/**
 * @brief Checks if an obstacle is detected by the sensor.
 * @return True if an obstacle is detected within a threshold distance, otherwise false.
 */
bool SafeNavigation::isObstacleDetected() {
    sensorInterface->update(); // Update sensor readings
    for (int i = 0; i < 9; ++i) { // Assuming the sensor has 9 detection points
        if (sensorInterface->getSensorValue(i) < 0.5) { // Assuming 0.5 is the threshold for detecting an obstacle
            cout << "Obstacle detected at sensor " << i << " with distance " << sensorInterface->getSensorValue(i) << endl;
            return true;
        }
    }
    return false;
}

/**
 * @brief Moves the robot forward safely, checking for obstacles.
 */
void SafeNavigation::moveForwardSafe() {
    if (!isObstacleDetected()) {
        controller->moveForward(); // Start moving forward
        state = MOVING;
    }
    else {
        state = STOP;
    }
}

/**
 * @brief Moves the robot backward safely, checking for obstacles.
 */
void SafeNavigation::moveBackwardSafe() {
    if (!isObstacleDetected()) {
        controller->moveBackward(); // Start moving backward
        state = MOVING;
    }
    else {
        state = STOP;
    }
}

/**
 * @brief Retrieves the current state of the robot.
 * @return The current state of the robot (STOP or MOVING).
 */
SafeNavigation::MOVESTATE SafeNavigation::getState() const {
    return state;
}


