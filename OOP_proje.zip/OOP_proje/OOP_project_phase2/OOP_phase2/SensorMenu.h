#ifndef SENSORMENU_H
#define SENSORMENU_H

#include "RobotControler.h"
#include "FestoRobotAPI.h"
#include "IRSensor.h"
#include "LidarSensor.h"

/**
 * @file FestoRobotSensorInterface.h
 * @brief Declaration of the FestoRobotSensorInterface class.
 * @details This class interfaces with the FestoRobotAPI to interact with the robot sensors.
 * @author R�meysa �elik  (152120211125@ogrenci.ogu.edu.tr)
 * @date December 2024
 */

 /**
  * @class SensorMenu
  * @brief Handles the sensor menu operations for a robot.
  */
class SensorMenu {
private:
    RobotControler* Control;     //!< Pointer to the robot controller
    FestoRobotAPI* robotAPI;     //!< Pointer to the robot API
    IRSensor* irSensor;          //!< Pointer to the IR sensor
    LidarSensor* lidarSensor;    //!< Pointer to the Lidar sensor
    int sensorChoice;            //!< Stores the user's menu choice

    /**
     * @brief Handles the menu choice.
     */
    void handleChoice();

    /**
     * @brief Displays the robot's pose.
     */
    void displayPose();

    /**
     * @brief Displays IR sensor data.
     */
    void displayIRSensorData();

    /**
     * @brief Displays Lidar sensor data.
     */
    void displayLidarSensorData();

    /**
     * @brief Updates all sensors.
     */
    void updateSensors();

public:
    /**
     * @brief Constructor for the SensorMenu class.
     *
     * Initializes the IR sensor and Lidar sensor and adds them to the robot controller.
     *
     * @param control Pointer to the RobotControler object.
     * @param api Pointer to the FestoRobotAPI object.
     */
    SensorMenu(RobotControler* control, FestoRobotAPI* api);

    /**
     * @brief Destructor for the SensorMenu class.
     *
     * Cleans up allocated resources for IR and Lidar sensors.
     */
    ~SensorMenu();

    /**
     * @brief Displays the sensor menu and handles user interaction.
     */
    void showMenu();
};

#endif // SENSORMENU_H
