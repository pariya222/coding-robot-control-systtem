#include "IRSensor.h"

/**
 * @file IRSensor.cpp
 * @brief Implementation of the IRSensor class for managing infrared sensor readings.
 *
 * This file contains the implementation of the IRSensor class, which interacts with the
 * robot API to retrieve infrared sensor data and provide functionality for accessing
 * sensor readings.
 *
 * @date December 2024
 * @author Mervenur Çakmakoğlu (152120221128@ogrenci.ogu.edu.tr)
 */

 /**
  * @brief Constructor for IRSensor.
  *
  * Initializes the IRSensor object with the FestoRobotAPI instance and sets all range values to 0.0.
  *
  * @param api Pointer to the FestoRobotAPI instance for sensor data retrieval.
  */
IRSensor::IRSensor(FestoRobotAPI* api) : FestoRobotSensorInterface(api) {
    for (int i = 0; i < 9; i++) {
        ranges[i] = 0.0; // T�m elemanlar� s�f�rla
    }
}

/**
 * @brief Destructor for IRSensor.
 *
 * The destructor is used to clean up any resources when the IRSensor object is destroyed.
 */
IRSensor::~IRSensor() = default;

/**
 * @brief Updates the sensor readings.
 *
 * Retrieves the latest infrared range values from the robot API and updates the ranges array.
 * The robot API is queried for the sensor data, which is then stored in the `ranges` array.
 */
void IRSensor::update() {
    if (robotAPI) {
        for (int i = 0; i < 9; i++) {
            ranges[i] = robotAPI->getIRRange(i); // Use the robotAPI to get sensor readings.
        }
    }
}

/**
 * @brief Gets the range value at a specific index.
 *
 * Provides access to a specific range value if the index is within bounds.
 * If the index is out of bounds, the function returns 0.0 as a default value.
 *
 * @param index The index of the range value (0 to 8).
 * @return The range value at the given index, or 0.0 if the index is out of bounds.
 */
double IRSensor::getRange(int index) const {
    if (index >= 0 && index < 9) {
        return ranges[index];
    }
    return 0.0;
}

/**
 * @brief Operator[] for accessing range values.
 *
 * Overloads the subscript operator to allow direct access to range values, like an array.
 * If the index is out of bounds, it returns 0.0 as the default value.
 *
 * @param index The index of the range value (0 to 8).
 * @return The range value at the given index, or 0.0 if the index is out of bounds.
 */
double IRSensor::operator[](int index) const {
    if (index >= 0 && index < 9) {
        return ranges[index];
    }
    return 0.0;
}

/**
 * @brief Gets the sensor type.
 *
 * This method returns the type of the sensor as a string. For this class, it will always
 * return "IR" for infrared.
 *
 * @return A string representing the sensor type ("IR").
 */
std::string IRSensor::getSensorType() const {
    return "IR";
}

/**
 * @brief Gets the sensor value at a specific index.
 *
 * This method retrieves the value of the sensor reading at the given index from the
 * `ranges` array. If the index is out of bounds, it returns 0.0 as the default value.
 *
 * @param index The index of the sensor reading (0 to 8).
 * @return The sensor value as a double, or 0.0 if the index is out of bounds.
 */
double IRSensor::getSensorValue(int index) const {
    if (index >= 0 && index < 9) {
        return ranges[index];
    }
    return 0.0;
}