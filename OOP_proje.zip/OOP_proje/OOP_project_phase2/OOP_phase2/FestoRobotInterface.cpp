#include "FestoRobotInterface.h"
#include <iostream>

/**
 * @file FestoRobotInterface.cpp
 * @brief This file contains the implementation of the FestoRobotInterface class.
 *
 * @author Mervenur �akmako�lu (152120221128@ogrenci.ogu.edu.tr)
 * @date December, 2024
 */

 /**
  * @class FestoRobotInterface
  * @brief Interface class for controlling the Festo robot.
  *
  * This class uses the FestoRobotAPI to control the robot's movements.
  */
FestoRobotInterface::FestoRobotInterface() {
    robotAPI = new FestoRobotAPI();
}

/**
 * @brief Destructor for FestoRobotInterface.
 *
 * This function deletes the robotAPI object when the interface is destroyed.
 */
FestoRobotInterface::~FestoRobotInterface() {
    delete robotAPI;
}

/**
 * @brief Rotates the robot to the left.
 *
 * This function calls the rotate method from the FestoRobotAPI to rotate the robot left.
 */
void FestoRobotInterface::turnLeft() {
    robotAPI->rotate(LEFT);
}

/**
 * @brief Rotates the robot to the right.
 *
 * This function calls the rotate method from the FestoRobotAPI to rotate the robot right.
 */
void FestoRobotInterface::turnRight() {
    robotAPI->rotate(RIGHT);
}

/**
 * @brief Moves the robot forward.
 *
 * This function calls the move method from the FestoRobotAPI to move the robot forward.
 */
void FestoRobotInterface::moveForward() {
    robotAPI->move(FORWARD);
}

/**
 * @brief Moves the robot backward.
 *
 * This function calls the move method from the FestoRobotAPI to move the robot backward.
 */
void FestoRobotInterface::moveBackward() {
    robotAPI->move(BACKWARD);
}

/**
 * @brief Moves the robot to the left.
 *
 * This function calls the move method from the FestoRobotAPI to move the robot left.
 */
void FestoRobotInterface::moveLeft() {
    robotAPI->move(LEFT);
}

/**
 * @brief Moves the robot to the right.
 *
 * This function calls the move method from the FestoRobotAPI to move the robot right.
 */
void FestoRobotInterface::moveRight() {
    robotAPI->move(RIGHT);
}

/**
 * @brief Stops the robot.
 *
 * This function calls the stop method from the FestoRobotAPI to stop the robot.
 */
void FestoRobotInterface::stop() {
    robotAPI->stop();
}

/**
 * @brief Returns the current pose of the robot.
 *
 * This function retrieves the robot's X, Y coordinates and orientation (theta)
 * from the FestoRobotAPI and returns them as a Pose object.
 *
 * @return Pose The current position and orientation of the robot.
 */
Pose FestoRobotInterface::getPose()const {
    double x, y, th;
    robotAPI->getXYTh(x, y, th); // Get the position and orientation from FestoRobotAPI
    return Pose(x, y, th);       // Return the Pose object
}

/**
 * @brief Prints the current pose of the robot.
 *
 * This function retrieves and prints the robot's current X, Y coordinates and orientation.
 */
void FestoRobotInterface::print() const{
    Pose pose = getPose();
    std::cout << "Robot Pose: (" << pose.getX() << ", " << pose.getY()
        << ", " << pose.getTh() << ")" << std::endl;
}

/**
 * @brief Connects to the robot.
 *
 * This function calls the connect method from the FestoRobotAPI to establish a connection to the robot.
 *
 * @return bool Returns true if the connection is successful.
 */
bool FestoRobotInterface::connectRobot() {
    robotAPI->connect();
    return true;
}

/**
 * @brief Disconnects from the robot.
 *
 * This function calls the disconnect method from the FestoRobotAPI to disconnect from the robot.
 *
 * @return bool Returns true if the disconnection is successful.
 */
bool FestoRobotInterface::disconnectRobot() {
    robotAPI->disconnect();
    return true;
}
