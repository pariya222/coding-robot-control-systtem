/**
 * @file RobotOperator.h
 * @brief Declaration of the RobotOperator class for managing operator details and authentication.
 * @details This class provides methods for securely storing and validating operator access codes, as well as managing operator information.
 * @author R�meysa �elik (152120211125@ogrenci.ogu.edu.tr)
 * @date December 2024
 */

#ifndef ROBOTOPERATOR_H
#define ROBOTOPERATOR_H

#include <string>
#include "Encryption.h"

 /**
  * @class RobotOperator
  * @brief Represents a robot operator with secure access control.
  */
class RobotOperator {
public:
    std::string name;       ///< Operator's first name
    std::string surname;    ///< Operator's surname
    unsigned int accessCode; ///< Encrypted access code
    bool accessState;       ///< Access state (true if access granted, false otherwise)

    /**
     * @brief Constructs a RobotOperator object with the given name, surname, and access code.
     * @param name The first name of the operator.
     * @param surname The surname of the operator.
     * @param code The 4-digit access code for the operator.
     */
    RobotOperator(const std::string& name, const std::string& surname, int code);

    /**
     * @brief Encrypts the given access code and stores it securely.
     * @param code The 4-digit access code to be encrypted.
     * @note If the code is not a 4-digit integer, an error message is displayed, and the access code is set to an invalid state.
     */
    void encryptCode(int code);

    /**
     * @brief Decrypts the stored access code.
     * @return The decrypted access code, or -1 if decryption fails.
     */
    int decryptCode() const;

    /**
     * @brief Validates the entered access code against the stored encrypted code.
     * @param enteredCode The 4-digit access code entered by the operator.
     * @return True if the entered code matches the stored code, false otherwise.
     */
    bool checkAccessCode(int enteredCode);

    /**
     * @brief Prints the operator's details, including name, surname, and access state.
     */
    void print() const;
};

#endif // ROBOTOPERATOR_H
