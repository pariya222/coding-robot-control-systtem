/**
 * @file MotionMenu.h
 * @brief Header file for the MotionMenu class.
 * @date december 2024
 * @Author Pariya Jahanbakhsh  (152120231154@ogrenci.ogu.edu.tr)
 */

#ifndef MOTIONMENU_H
#define MOTIONMENU_H

#include "RobotControler.h"
#include "SafeNavigation.h"

 /**
  * @class MotionMenu
  * @brief Provides a menu interface to control robot motions and safe navigation.
  */
class MotionMenu {
private:
    RobotControler* Control; ///< Pointer to the robot controller.
    int choice;              ///< Variable to store the menu selection.
    SafeNavigation* SafeNav; ///< Pointer to the safe navigation system.

public:
    /**
     * @brief Constructs a MotionMenu object.
     * @param control Pointer to the RobotControler instance.
     * @param safeNav Pointer to the SafeNavigation instance.
     * @param Choice Initial choice for the menu.
     */
    MotionMenu(RobotControler* control, SafeNavigation* safeNav, int Choice);

    /**
     * @brief Destructor for the MotionMenu class.
     */
   

    /**
     * @brief Displays the motion menu and allows user interaction.
     */
    void showMenu();

    /**
     * @brief Processes the user's menu selection and executes the corresponding action.
     */
    void ExecuteChoice();
};

#endif // MOTIONMENU_H
