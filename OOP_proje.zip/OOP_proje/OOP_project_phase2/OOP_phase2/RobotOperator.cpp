/**
 * @file RobotOperator.cpp
 * @brief Implementation of the RobotOperator class for managing robot operator details and authentication.
 * @details This class handles operator information, secure access code encryption, decryption, and validation.
 * @author R�meysa �elik (152120211125@ogrenci.ogu.edu.tr)
 * @date December 2024
 */

#include "RobotOperator.h"
#include <iostream>
#include "Encryption.h"

using namespace std; ///< Using the standard namespace

/**
 * @brief Constructs a RobotOperator object with the given name, surname, and access code.
 * @param name The first name of the operator.
 * @param surname The surname of the operator.
 * @param code The 4-digit access code for the operator.
 */
RobotOperator::RobotOperator(const string& name, const string& surname, int code)
    : name(name), surname(surname), accessState(false) {
    encryptCode(code); ///< Encrypt and store the access code
}

/**
 * @brief Encrypts the given access code and stores it securely.
 * @param code The 4-digit access code to be encrypted.
 * @note If the code is not a 4-digit integer, an error message is displayed, and the access code is set to an invalid state.
 */
void RobotOperator::encryptCode(int code) {
    if (code < 1000 || code > 9999) {
        cerr << "Error: Access code must be a 4-digit integer.\n";
        accessCode = 0; ///< Set to an invalid state
        return;
    }
    Encryption encryption;
    accessCode = encryption.encrypt(code);
}

/**
 * @brief Decrypts the stored access code.
 * @return The decrypted access code, or -1 if decryption fails.
 */
int RobotOperator::decryptCode() const {
    Encryption encryption;
    int decryptedCode = encryption.decrypt(accessCode);

    if (decryptedCode == -1) {
        cerr << "Error: Failed to decrypt access code.\n";
        return -1; ///< Return an error code
    }

    return decryptedCode;
}

/**
 * @brief Validates the entered access code against the stored encrypted code.
 * @param enteredCode The 4-digit access code entered by the operator.
 * @return True if the entered code matches the stored code, false otherwise.
 * @note Updates the access state based on the validation result.
 */
bool RobotOperator::checkAccessCode(int enteredCode) {
    if (enteredCode < 1000 || enteredCode > 9999) {
        cerr << "Error: Entered code must be a 4-digit integer.\n";
        return false;
    }

    bool isCorrect = enteredCode == decryptCode();
    accessState = isCorrect; ///< Update accessState directly

    return isCorrect;
}

/**
 * @brief Prints the operator's details, including name, surname, and access state.
 */
void RobotOperator::print() const {
    cout << "Operator: " << name << " " << surname << "\n";
    cout << "Access State: " << (accessState ? "Granted" : "Denied") << "\n";
}
