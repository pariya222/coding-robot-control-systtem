#ifndef IRSENSOR_H
#define IRSENSOR_H

#include "FestoRobotAPI.h"

/**
 * @file IRSensor.h
 * @author  Mervenur �akmako�lu (152120221128@ogrenci.ogu.edu.tr)
 * @date December 2024
 * @brief Header file for the IRSensor class.
 *
 * This file defines the IRSensor class which handles infrared sensor readings.
 * It provides methods for updating and retrieving sensor data from the robot's infrared sensors.
 * The IRSensor class interacts with the FestoRobotAPI to get the data.
 */

 /**
  * @class IRSensor
  * @brief A class to handle infrared sensor readings for the robot.
  *
  * This class provides functionality to update and retrieve sensor values from the infrared sensors.
  * It uses the FestoRobotAPI to interact with the robot and access sensor data.
  */
class IRSensor {
protected:
    /** Pointer to the FestoRobotAPI object */
    FestoRobotAPI* robotAPI;

    /** Array to hold sensor range readings from 9 sensors */
    double ranges[9];

public:
    /**
     * @brief Constructor to initialize the IRSensor with the robot API.
     *
     * This constructor sets up the robot API and initializes the sensor readings.
     * @param api A pointer to the FestoRobotAPI object used to interact with the robot.
     */
    explicit IRSensor(FestoRobotAPI* api);

    /**
     * @brief Virtual destructor for IRSensor.
     *
     * The destructor ensures proper cleanup when the IRSensor object is destroyed.
     */
    virtual ~IRSensor() = default;

    /**
     * @brief Virtual method to update the sensor readings.
     *
     * This method retrieves new data from the infrared sensors and updates the readings.
     */
    virtual void update();

    /**
     * @brief Get the range value at a specific index.
     *
     * This method returns the range value of the infrared sensor at the specified index.
     * @param index The index of the infrared sensor (0 to 8).
     * @return The range value of the specified sensor.
     */
    virtual double getRange(int index);

    /**
     * @brief Operator[] for accessing sensor ranges.
     *
     * This operator allows array-like access to the sensor readings.
     * @param index The index of the sensor (0 to 8).
     * @return The range value of the specified sensor.
     */
    virtual double operator[](int index);
};

#endif // IRSENSOR_H

