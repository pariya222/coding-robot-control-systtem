#include <iostream>
#include "Pose.h"

/**
 * @file PoseTest.cpp
 * @author Mervenur �akmako�lu (152120221128@ogrenci.ogu.edu.tr)
 * @date December, 2024
 * @brief Tests for the Pose class methods and operators.
 */

using namespace std;

/**
 * @brief Test the default constructor and getter methods of the Pose class.
 */
void Test1() {
    Pose p1; // Default constructor
    cout << "Test1: Initial Pose (p1): (" << p1.getX() << ", " << p1.getY() << ", " << p1.getTh() << ")\n";
}

/**
 * @brief Test the parameterized constructor and getter methods of the Pose class.
 */
void Test2() {
    Pose p2(3.0, 4.0, 45.0);
    cout << "Test2: Pose p2: (" << p2.getX() << ", " << p2.getY() << ", " << p2.getTh() << ")\n";
}

/**
 * @brief Test setter and getter methods of the Pose class.
 */
void Test3() {
    Pose p1; // Default constructor
    p1.setX(1.0);
    p1.setY(2.0);
    p1.setTh(30.0);
    cout << "Test3: Pose p1 after setX, setY, setTh: (" << p1.getX() << ", " << p1.getY() << ", " << p1.getTh() << ")\n";
}

/**
 * @brief Test getPose and setPose methods of the Pose class.
 */
void Test4() {
    Pose p1(1.0, 2.0, 30.0);
    double x, y, th;
    p1.getPose(x, y, th);
    cout << "Test4: Pose p1 from getPose: (" << x << ", " << y << ", " << th << ")\n";

    p1.setPose(2.0, 2.0, 90.0);
    cout << "Test4: Pose p1 after setPose: (" << p1.getX() << ", " << p1.getY() << ", " << p1.getTh() << ")\n";
}

/**
 * @brief Test the equality operator (==) of the Pose class.
 */
void Test5() {
    Pose p1(2.0, 2.0, 90.0);
    Pose p2(2.0, 2.0, 90.0);
    Pose p3(5.0, 5.0, 90.0);

    cout << "Test5: Pose equality test (p1 == p2): " << (p1 == p2 ? "Equal" : "Not Equal") << "\n";
    cout << "Test5: Pose equality test (p1 == p3): " << (p1 == p3 ? "Equal" : "Not Equal") << "\n";
}

/**
 * @brief Test the addition (+) and subtraction (-) operators of the Pose class.
 */
void Test6() {
    Pose p1(2.0, 2.0, 90.0);
    Pose p2(3.0, 4.0, 45.0);

    Pose p3 = p1 + p2;
    cout << "Test6: Pose addition (p1 + p2): (" << p3.getX() << ", " << p3.getY() << ", " << p3.getTh() << ")\n";

    Pose p4 = p2 - p1;
    cout << "Test6: Pose subtraction (p2 - p1): (" << p4.getX() << ", " << p4.getY() << ", " << p4.getTh() << ")\n";
}

/**
 * @brief Test the compound assignment operators (+= and -=) of the Pose class.
 */
void Test7() {
    Pose p1(2.0, 2.0, 90.0);
    Pose p2(3.0, 4.0, 45.0);

    p1 += p2;
    cout << "Test7: Pose after p1 += p2: (" << p1.getX() << ", " << p1.getY() << ", " << p1.getTh() << ")\n";

    p2 -= p1;
    cout << "Test7: Pose after p2 -= p1: (" << p2.getX() << ", " << p2.getY() << ", " << p2.getTh() << ")\n";
}

/**
 * @brief Test the less-than (<) operator of the Pose class.
 */
void Test8() {
    Pose p1(2.0, 2.0, 90.0);
    Pose p2(5.0, 5.0, 90.0);

    cout << "Test8: Pose comparison (p1 < p2): " << (p1 < p2 ? "True" : "False") << "\n";
}

/**
 * @brief Test the distance calculation method of the Pose class.
 */
void Test9() {
    Pose p1(2.0, 2.0, 90.0);
    Pose p2(6.0, 8.0, 90.0);

    double distance = p1.findDistanceTo(p2);
    cout << "Test9: Distance from p1 to p2: " << distance << "\n";
}

/**
 * @brief Test the angle calculation method of the Pose class.
 */
void Test10() {
    Pose p1(2.0, 2.0, 90.0);
    Pose p2(6.0, 8.0, 90.0);

    double angle = p1.findAngleTo(p2);
    cout << "Test10: Angle from p1 to p2: " << angle << " degrees\n";
}

/**
 * @brief Main function to execute all the test cases for the Pose class.
 *
 * This function sequentially calls all the test functions to validate
 * the implementation of the Pose class.
 *
 * @return int Exit status of the program.
 */
int main() {
    // Calling tests in sequence
    Test1();
    Test2();
    Test3();
    Test4();
    Test5();
    Test6();
    Test7();
    Test8();
    Test9();
    Test10();

    return 0;
}