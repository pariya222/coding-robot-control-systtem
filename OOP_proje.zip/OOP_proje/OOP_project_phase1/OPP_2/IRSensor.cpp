#include "IRSensor.h"

/**
 * @file IRSensor.cpp
 * @author Mervenur �akmako�lu (152120221128@ogrenci.ogu.edu.tr)
 * @date December, 2024
 * @brief Implementation of the IRSensor class for managing infrared sensor readings from a robot.
 */

 /**
  * @brief Constructor for IRSensor.
  *
  * Initializes the IRSensor object with a FestoRobotAPI instance and sets all range values to 0.0.
  *
  * @param api Pointer to the FestoRobotAPI instance for sensor data retrieval.
  */
IRSensor::IRSensor(FestoRobotAPI* api) : robotAPI(api) {
    for (int i = 0; i < 9; i++) {
        ranges[i] = 0.0; // Initialize all ranges to 0.0
    }
}

/**
 * @brief Updates the sensor readings.
 *
 * Retrieves the latest infrared range values from the robot API and updates the ranges array.
 */
void IRSensor::update() {
    if (robotAPI) {
        for (int i = 0; i < 9; i++) {
            ranges[i] = robotAPI->getIRRange(i);
        }
    }
}

/**
 * @brief Gets the range value at a specific index.
 *
 * Provides access to a specific range value if the index is within bounds.
 *
 * @param index The index of the range value (0 to 8).
 * @return The range value at the given index, or 0.0 if the index is out of bounds.
 */
double IRSensor::getRange(int index) {
    if (index >= 0 && index < 9) {
        return ranges[index];
    }
    return 0.0;
}

/**
 * @brief Operator[] for accessing range values.
 *
 * Overloads the subscript operator to allow direct access to range values.
 *
 * @param index The index of the range value (0 to 8).
 * @return The range value at the given index, or 0.0 if the index is out of bounds.
 */
double IRSensor::operator[](int index) {
    if (index >= 0 && index < 9) {
        return ranges[index];
    }
    return 0.0;
}
