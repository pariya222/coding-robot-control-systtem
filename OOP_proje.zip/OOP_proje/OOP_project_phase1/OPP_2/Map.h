/**
 * @file Map.h
 * @brief Declaration of the Map class
 * @details This class represents a map grid and provides various operations to manipulate the grid.
 * @date December, 2024
 * @author �zge Erarslan (152120221095@ogrenci.ogu.edu.tr)
 */

#ifndef MAP_H
#define MAP_H

#include <iostream>
#include "Point.h"

using namespace std;

/**
 * @class Map
 * @brief A class representing a map grid
 */
class Map {
    int** grid; ///< 2D array to hold the grid data
    int numberX; ///< Number of grid columns
    int numberY; ///< Number of grid rows
    double gridSize; ///< Size of each grid cell

public:
    /**
     * @brief Constructor for Map
     * @param x Number of columns
     * @param y Number of rows
     * @param size Size of each grid cell
     */
    Map(int x, int y, double size);

    /**
     * @brief Inserts a point into the grid
     * @param point The point to insert
     */
    void insertPoint(Point point);

    /**
     * @brief Gets the grid value at the specified indices
     * @param indexX The x index
     * @param indexY The y index
     * @return The grid value at the specified indices
     */
    int getGrid(int indexX, int indexY);

    /**
     * @brief Sets the grid value at the specified indices
     * @param indexX The x index
     * @param indexY The y index
     * @param value The value to set
     */
    void setGrid(int indexX, int indexY, int value);

    /**
     * @brief Clears the map grid
     */
    void clearMap();

    /**
     * @brief Prints information about the map
     */
    void printInfo() const;

    /**
     * @brief Overloads the << operator to output the map
     * @param os The output stream
     * @param map The map object
     * @return The output stream
     */
    friend ostream& operator<<(std::ostream& os, const Map& map);

    /**
     * @brief Displays the map grid
     */
    void showMap();

    /**
     * @brief Gets the number of columns in the grid
     * @return The number of columns
     */
    int getNumberX() const;

    /**
     * @brief Gets the number of rows in the grid
     * @return The number of rows
     */
    int getNumberY() const;

    /**
     * @brief Adds the size of the grid cell
     * @return The size of the grid cell
     */
    double addGridSize();

    /**
     * @brief Sets the size of the grid cell
     * @param size The new size of the grid cell
     */
    void setGridSize(double size);

    /**
     * @brief Destructor for Map
     */
    ~Map();
};

#endif // MAP_H
