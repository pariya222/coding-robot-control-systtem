/**
 * @file Point.h
 * @brief Declaration of the Point class
 * @details This class represents a point in a 2D space and provides various operations to manipulate the point.
 * @date December, 2024
 * @author �zge Erarslan (152120221095@ogrenci.ogu.edu.tr)
 */

#ifndef POINT_H
#define POINT_H

#include <iostream>
#include "Pose.h"

 /**
  * @class Point
  * @brief A class representing a point in a 2D space.
  */
class Point {
    double x; ///< X coordinate of the point
    double y; ///< Y coordinate of the point

public:
    /**
     * @brief Constructor for Point
     * @param _x The x coordinate
     * @param _y The y coordinate
     */
    Point(double _x, double _y);

    /**
     * @brief Gets the x coordinate of the point
     * @return The x coordinate
     */
    double getX() const;

    /**
     * @brief Sets the x coordinate of the point
     * @param _x The new x coordinate
     */
    void setX(double _x);

    /**
     * @brief Gets the y coordinate of the point
     * @return The y coordinate
     */
    double getY() const;

    /**
     * @brief Sets the y coordinate of the point
     * @param _y The new y coordinate
     */
    void setY(double _y);

    /**
     * @brief Compares the point to another Pose
     * @param other The other Pose to compare to
     * @return True if the point is equal to the other Pose, false otherwise
     */
    bool operator==(const Pose& other);

    /**
     * @brief Gets the coordinates of the point
     * @param _x Reference to store the x coordinate
     * @param _y Reference to store the y coordinate
     */
    void getPoint(double& _x, double& _y);

    /**
     * @brief Sets the coordinates of the point
     * @param _x The new x coordinate
     * @param _y The new y coordinate
     */
    void setPoint(double _x, double _y);

    /**
     * @brief Finds the distance to another point
     * @param pos The other point
     * @return The distance to the other point
     */
    double findDistanceTo(Point pos);

    /**
     * @brief Finds the angle to another point
     * @param pos The other point
     * @return The angle to the other point
     */
    double findAngleTo(Point pos);
};

#endif // POINT_H
