#include "IRSensor.h"
#include "FestoRobotAPI.h"
#include <iostream>
using namespace std;

/**
 * @file IRSensorTest.cpp
 * @author Mervenur �akmako�lu (152120221128@ogrenci.ogu.edu.tr)
 * @date December, 2024
 * @brief Main program to demonstrate interaction with IRSensor and robot movement using FestoRobotAPI.
 */

FestoRobotAPI* robotino;

/**
 * @brief Prints the IR sensor readings.
 *
 * This function retrieves the robot's pose (position and orientation) and updates the IR sensor readings.
 * It then prints the sensor readings using both the operator[] and getRange method.
 */
void print() {
    /** Get robot's pose */
    double x, y, th;
    robotino->getXYTh(x, y, th);

    /** Create IRSensor object */
    IRSensor sensor(robotino);
    sensor.update();  /**< Update sensor readings */

    /** Print sensor values using operator[] */
    for (int i = 0; i < 9; i++) {
        cout << sensor[i] << endl;
        cout << "----------------------------------------------------------------------" << endl;

        /** Print sensor values using getRange method */
        cout << "getRange= " << sensor.getRange(i) << endl;
    }
}

/**
 * @brief Main function to control robot movement and print sensor values.
 *
 * This function connects to the robot, performs several movements (forward, backward, left, right, and rotation),
 * and prints the corresponding sensor values after each movement.
 * It also disconnects from the robot at the end.
 *
 * @return int Exit status code.
 */
int main() {
    /** Create connection to robot */
    robotino = new FestoRobotAPI();

    cout << "----------------------------------------------------------------------" << endl;

    /** Make connection to robot */
    robotino->connect();
    Sleep(2000);  /**< Wait for the robot to connect */
    print();      /**< Print sensor values */

    /** Move forward and print sensor values */
    robotino->move(FORWARD);
    Sleep(2000);
    robotino->stop();
    print();

    /** Move backward and print sensor values */
    robotino->move(BACKWARD);
    Sleep(2000);
    robotino->stop();
    print();

    /** Move left and print sensor values */
    robotino->move(LEFT);
    Sleep(2000);
    robotino->stop();
    print();

    /** Move right and print sensor values */
    robotino->move(RIGHT);
    Sleep(2000);
    robotino->stop();
    print();

    /** Turn left and print sensor values */
    robotino->rotate(LEFT);
    Sleep(2000);
    robotino->stop();
    print();

    /** Turn right and print sensor values */
    robotino->rotate(RIGHT);
    Sleep(2000);
    robotino->stop();
    print();

    /** Close connection to the robot */
    robotino->disconnect();

    /** Delete the robot object */
    delete robotino;

    return 0;
}