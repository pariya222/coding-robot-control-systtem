/**
 * @file SafeNavigation.h
 * @brief Declaration of the SafeNavigation class, which provides obstacle-aware navigation for a robot.
 * @author Pariya Jahanbakhsh
 * @contact (152120231154@ogrenci.ogu.edu.tr)
 * @date December 2024
 */

#ifndef SAFENAVIGATION_H
#define SAFENAVIGATION_H

#include "RobotControler.h"
#include "IRSensor.h"
#include <iostream>

 /**
  * @class SafeNavigation
  * @brief A class to manage safe navigation for a robot by detecting obstacles and controlling movement.
  */
class SafeNavigation {
public:
    /**
     * @enum State
     * @brief Enum to represent the current state of the robot.
     */
    enum State {
        STOP,   /**< The robot is stopped */
        MOVING  /**< The robot is moving */
    };

    /**
     * @brief Constructor for the SafeNavigation class.
     * @param rc Pointer to a RobotControler object for controlling the robot's movements.
     * @param ir Pointer to an IRSensor object for detecting obstacles.
     */
    SafeNavigation(RobotControler* rc, IRSensor* ir);

    /**
     * @brief Checks if an obstacle is detected using the IR sensor.
     * @return True if an obstacle is detected within a threshold distance, otherwise false.
     */
    bool isObstacleDetected();

    /**
     * @brief Moves the robot forward safely, checking for obstacles.
     */
    void moveForwardSafe();

    /**
     * @brief Moves the robot backward safely, checking for obstacles.
     */
    void moveBackwardSafe();

    /**
     * @brief Retrieves the current state of the robot.
     * @return The current state of the robot (STOP or MOVING).
     */
    State getState() const;

private:
    RobotControler* controller; /**< Pointer to the robot controller */
    IRSensor* irSensor;         /**< Pointer to the IR sensor for obstacle detection */
    State state;                /**< The state of the robot (STOP or MOVING) */
};

#endif // SAFENAVIGATION_H
