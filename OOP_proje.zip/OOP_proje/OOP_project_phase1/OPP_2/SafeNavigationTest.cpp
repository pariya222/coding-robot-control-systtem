/**
 * @file SafeNavigationTest.cpp
 * @brief Test program for the SafeNavigation class using mock implementations of RobotControler and IRSensor.
 * @details This file tests the obstacle detection and safe movement functionality of the SafeNavigation class using mock objects.
 * @author Pariya Jahanbakhsh
 * @contact (152120231154@ogrenci.ogu.edu.tr)
 * @date December 2024
 */

#include "SafeNavigation.h"
#include "RobotControler.h"
#include "IRSensor.h"
#include <iostream>
#include <vector>

using namespace std;

/**
 * @class MockRobotControler
 * @brief Mock implementation of the RobotControler class for testing purposes.
 */
class MockRobotControler : public RobotControler {
public:
    MockRobotControler() : RobotControler(nullptr, nullptr) {}

    /**
     * @brief Simulates moving the robot forward.
     */
    void moveForward() {
        std::cout << "Robot is moving forward." << std::endl;
    }

    /**
     * @brief Simulates moving the robot backward.
     */
    void moveBackward() {
        std::cout << "Robot is moving backward." << std::endl;
    }

    /**
     * @brief Simulates stopping the robot.
     */
    void stop() {
        std::cout << "Robot has stopped." << std::endl;
    }
};

/**
 * @class MockIRSensor
 * @brief Mock implementation of the IRSensor class for testing purposes.
 */
class MockIRSensor : public IRSensor {
private:
    double ranges[9]; /**< Array to store sensor ranges */

public:
    /**
     * @brief Constructor for the MockIRSensor class.
     * @param api Pointer to a FestoRobotAPI object (can be nullptr for testing).
     */
    MockIRSensor(FestoRobotAPI* api) : IRSensor(api) {
        for (int i = 0; i < 9; i++) {
            ranges[i] = 1.0; // Initialize all ranges to 1.0
        }
    }

    /**
     * @brief Simulates updating the sensor readings.
     */
    void update() {
        // No actual logic needed for the mock implementation
    }

    /**
     * @brief Gets the range of a specific sensor.
     * @param index The index of the sensor (0 to 8).
     * @return The range value for the specified sensor.
     */
    double getRange(int index) {
        if (index >= 0 && index < 9) {
            return ranges[index];
        }
        return 0.0; // Return 0.0 for out-of-bounds indices
    }

    /**
     * @brief Overloaded operator[] to get the range of a specific sensor.
     * @param index The index of the sensor (0 to 8).
     * @return The range value for the specified sensor.
     */
    double operator[](int index) {
        if (index >= 0 && index < 9) {
            return ranges[index];
        }
        return 0.0;
    }

    /**
     * @brief Sets the range of a specific sensor.
     * @param index The index of the sensor (0 to 8).
     * @param value The value to set for the sensor range.
     */
    void setRange(int index, double value) {
        if (index >= 0 && index < 9) {
            ranges[index] = value;
        }
    }
};

/**
 * @brief Main function to test the SafeNavigation class.
 * @return int Returns 0 on successful execution.
 */
int main() {
    // Create mock objects
    MockRobotControler mockController;
    MockIRSensor mockSensor(nullptr); // Pass nullptr for FestoRobotAPI

    // Create SafeNavigation instance
    SafeNavigation safeNav(&mockController, &mockSensor);

    // Test moveForwardSafe when no obstacles are detected
    std::cout << "Testing moveForwardSafe with no obstacles..." << std::endl;
    safeNav.moveForwardSafe();

    // Simulate an obstacle
    mockSensor.setRange(4, 0.4);
    std::cout << "Testing moveForwardSafe with an obstacle..." << std::endl;
    safeNav.moveForwardSafe();

    // Test moveBackwardSafe with no obstacles
    mockSensor.setRange(4, 1.0); // Clear obstacle
    std::cout << "Testing moveBackwardSafe with no obstacles..." << std::endl;
    safeNav.moveBackwardSafe();

    // Simulate an obstacle while moving backward
    mockSensor.setRange(2, 0.3);
    std::cout << "Testing moveBackwardSafe with an obstacle..." << std::endl;
    safeNav.moveBackwardSafe();

    std::cout << "All tests completed." << std::endl;
    return 0;
}

